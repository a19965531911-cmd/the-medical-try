MOCK paired original158 cases and unchanged model responses:
{
  "B7_1H": {
    "metrics": {
      "n": 158,
      "tp": 50,
      "fp": 0,
      "fn": 7,
      "tn": 101,
      "precision": 1.0,
      "recall": 0.8771929824561403,
      "f1": 0.9345794392523364
    },
    "calls": 68,
    "rescues": 8,
    "productive_rate": 0.11764705882352941,
    "accepted_facts": 14,
    "facts_per_call": 0.20588235294117646,
    "calls_per_rescue": 8.5,
    "robust_metrics": {
      "n": 29,
      "tp": 23,
      "fp": 0,
      "fn": 0,
      "tn": 6,
      "precision": 1.0,
      "recall": 1.0,
      "f1": 1.0
    }
  },
  "B7_2H": {
    "metrics": {
      "n": 158,
      "tp": 50,
      "fp": 0,
      "fn": 7,
      "tn": 101,
      "precision": 1.0,
      "recall": 0.8771929824561403,
      "f1": 0.9345794392523364
    },
    "calls": 60,
    "rescues": 8,
    "productive_rate": 0.13333333333333333,
    "accepted_facts": 14,
    "facts_per_call": 0.23333333333333334,
    "calls_per_rescue": 7.5,
    "robust_metrics": {
      "n": 29,
      "tp": 22,
      "fp": 0,
      "fn": 1,
      "tn": 6,
      "precision": 1.0,
      "recall": 0.9565217391304348,
      "f1": 0.9777777777777777
    }
  }
}
Only calls with exclusively protected deterministic atoms suppressed. No broad anchor filter and no removal of difficult categorical cases. No clinical recall gained on original responses; reduced calls are nonrescuable numeric/duration/vessel inquiries. Repeated unproductive empty fixtures cannot establish Qwen behavior. Valid accepted facts-per-call is measured, not raw grounded proposals.

Original68 mutually exclusive coarse attribution: {"成功救援": 8, "事实本身不成立：上下文拒绝": 12, "来源绑定失败或Schema失败（旧计数无法拆分）": 7, "已有事实重复或无接受事实（旧记录无法唯一细分）": 7, "无有效事实返回（不是已知无必要触发）": 34}
Historical log cannot retrospectively distinguish all binding/schema errors; explicit unknown retained.
