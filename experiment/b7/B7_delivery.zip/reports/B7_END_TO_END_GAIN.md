{"B6H": {"n": 43, "tp": 7, "fp": 0, "fn": 0, "tn": 36, "precision": 1.0, "recall": 1.0, "f1": 1.0}, "B7H": {"n": 43, "tp": 7, "fp": 0, "fn": 0, "tn": 36, "precision": 1.0, "recall": 1.0, "f1": 1.0}}
Same fixed responses and Service. Both systems already support categorical rescue; no B7-specific recall improvement claimed.
